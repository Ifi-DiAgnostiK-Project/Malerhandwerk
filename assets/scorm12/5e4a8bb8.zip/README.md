<!--
author:    Hilke Domsch
email:     hilke.domsch@gkz-ev.de
version:   0.0.11
date:      2025-08-01

language:  de
narrator:  Deutsch Male

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/malerhandwerk-grundkurs-g-ml-24

title:     Grundkurs Maler/Lackierer G-ML-24
comment:   Grundkurs Maler/Lackierer

tags:      Maler,
           Grundkurs

icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png
logo:      assets/images/farben.jpg

attribute: Title Image by Pixabay, Darkmoon Art

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_DragAndDrop_Template/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Piktogramme/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_ImageQuiz/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Bildersammlung/refs/heads/main/makros.md
-->

# Grundstufe Maler- und Lackiererhandwerk G-ML-24  🧑‍🎨

Sie haben in den letzten Tagen Werkzeuge und Grundhandgriffe im Maler- und Lackiererhandwerk kennengelernt und eingeübt. <br> <br> __Überprüfen Sie Ihr Wissen.__


<!-- class="highlight" -->
Wir wünschen Ihnen viel Erfolg beim Beantworten der Fragen!

<br> <br>
<center>

@Maler_Planung.Uebung3_Ergebnis(55)<br><br>_Quelle aller Bilder: HWK Dresden, Florian Riefling_

</center>

## Typische Werkzeuge im Maler- und Lackiererhandwerk I

><!--style="color: red; font-weight: bolder"-->Es sind insgesamt vier Antworten richtig!


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Wie nennt man dieses Werkzeug?
------------------------------

<!-- data-randomize -->
- [[ ]] Kamm
- [[X]] Abreißblech
- [[X]] Rakel
- [[X]] Schwedenblech
- [[ ]] Blockschiene
- [[X]] Flächenrakel

</div>
<div class="flex-child">

![Abreißblech](assets/images/spachtel.jpg)<!-- style="width: 350px" -->

</div>
</section>



## Typische Werkzeuge im Maler- und Lackiererhandwerk II

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Wie nennt man dieses Werkzeug?
------------------------------

<!-- data-randomize -->
- [( )] Kehrbesen
- [( )] Wandbürste
- [(X)] Tapezierbürste

</div>
<div class="flex-child">

![Tapezierbürste](assets/images/buerste.jpg)<!-- style="width: 250px" -->

</div>
</section>

## Typische Werkzeuge im Maler- und Lackiererhandwerk III

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Wie nennt man dieses Werkzeug?
------------------------------

<!-- data-randomize -->
- [( )] Ringpinsel
- [( )] Heizkörperpinsel
- [(X)] Schrägstrichzieher

</div>
<div class="flex-child">

![Schraegstrichzieher](assets/images/kleiner_pinsel.jpg)<!-- style="width: 350px" -->

</div>
</section>



## Wichtige Arbeitsabläufe für allgemeine Decken- und Wandgestaltungen


Sie sollen in einem Raum Decken und Wände gestalten. -- In welcher Reihenfolge führen Sie diesen Auftrag aus?


<section class="flex-container border">
<div class="flex-child">


<!-- class="highlight"-->
Ziehen Sie die einzelnen Arbeitsschritte in die richtige Reihenfolge.\
An oberster Stelle steht der erste Arbeitsschritt.


<!-- data-randomize data-show-partial-solution -->
@dragdroporder(@uid,Anschlussflächen abdecken und abkleben wie Türen - Fenster - Fußboden| Nicht tragfähige Beschichtung und Beläge von den Wand- und Deckenflächen entfernen.|Wand- und Deckenflächen nachwaschen.|Wand- und Deckenflächen spachteln.|Wand- und Deckenflächen schleifen und entstauben.|Wand- und Deckenflächen mit unpigmentierter sowie wasserverdünnter Grundbeschichtung grundieren.|Tapezieren von Raufaser an der Deckenfläche.|Makulatur oder Glattvlies kleben.|Decken- und Wandanschlüsse beschneiden und Zwischenbeschichtung applizieren.|Decken- und Wandanschlüsse beschneiden und Schlussbeschichtung applizieren.)

</div>
<div class="flex-child-0">

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

![Miniaturfigur eines Malers steht vor bunt gestrichenen Holzbrettern und hält einen Farbeimer; darüber befindet sich eine grüne Farbrolle.](assets/images/maler_mini_holzwand.jpg "Miniatur-Malerfigur vor einer bunt gestrichenen Holzwand. Bild von [Ralphs_Fotos via Pixabay](https://pixabay.com/de/photos/maler-malerei-lackierer-3177366/), Pixabay Content License, veröffentlicht am 2. März 2018.")<!-- style="width: 500px" -->


</div>
</section>

## Wichtige Arbeitsabläufe für Gestaltungsflächen -  Wände


Sie sollen in einem Raum Wände und Sockel gestalten. -- In welcher Reihenfolge führen Sie diesen Auftrag aus?

<!--style="color: green"-->Aufgabe 1: Wände

<section class="flex-container border">
<div class="flex-child">


<!-- class="highlight"-->
Ziehen Sie die einzelnen Arbeitsschritte in die richtige Reihenfolge.\
An oberster Stelle steht der erste Arbeitsschritt.

<!-- data-randomize data-show-partial-solution -->
@dragdroporder(@uid,Gestaltungswand: Flächengliederung abmessen und anzeichnen.|Farbflächen mit Strichzieher und Lineal beschneiden.|Farbflächen mit Pinsel deckend farbig auslegen.|Radius auf der rechten Seite anzeichnen und deckend farbig auslegen.|Kontrastlinien mit Lineal und Strichzieher ziehen.|Wickeltechnik über die gesamte Gestaltung mit Latexbindemittel -glänzend- ausführen.)


</div>
<div class="flex-child-0">

<br>
<br>
<br>
<br>

![Kleine Malerfigur mit grünem Farbroller und Farbeimer steht draußen auf einem Weg.](assets/images/maler_mini.jpg "Malerfigur mit Farbroller und Farbeimer im Freien. Bild von [Alexas_Fotos via Pixabay](https://pixabay.com/photos/painter-to-brush-work-figure-1116746/), Pixabay Content License, veröffentlicht am 5. Januar 2016.")<!-- style="width: 500px" -->


</div>
</section>



## Wichtige Arbeitsabläufe für Gestaltungsflächen - Sockel


Sie sollen in einem Raum Wände und Sockel gestalten. -- In welcher Reihenfolge führen Sie diesen Auftrag aus?

<!--style="color: green"-->Aufgabe 2: Sockel


<section class="flex-container border">
<div class="flex-child">


<!-- class="highlight"-->
Ziehen Sie die einzelnen Arbeitsschritte in die richtige Reihenfolge.\
An oberster Stelle steht der erste Arbeitsschritt.

<!-- data-randomize data-show-partial-solution -->
@dragdroporder(@uid,Sockelfläche einmessen und abkleben/abdecken.|Wickeltechnik zweifarbig im Sockelbereich ausführen.|Fläche der Wickeltechnik mit Strichzieher und Lineal einrahmen.|Abklebung und Abdeckung entfernen. Abfälle sachgerecht entsorgen und Werkzeuge und Arbeitsmittel reinigen.)

</div>
<div class="flex-child-0">

<br>
<br>

![Kleine Malerfigur von hinten mit weißer Arbeitskleidung und Farbroller im Freien.](assets/images/maler_mini_back.jpg "Malerfigur mit Farbroller auf einem Weg im Freien. Bild von [Alexas_Fotos via Pixabay](https://pixabay.com/photos/painter-to-brush-work-figure-1116763/), Pixabay Content License, veröffentlicht am 5. Januar 2016.")<!-- style="width: 500px" -->


</div>
</section>


### Beschaffenheit von Untergründen

><!--style="color: red; font-weight: bolder"-->Es sind insgesamt fünf Antworten richtig!

<section class="flex-container border">
<div class="flex-child">


<!-- class="highlight" -->
Wie sollte ein Untergrund beschaffen sein, damit dieser beschichtet oder tapeziert werden kann?


<!-- data-randomize -->
- [[X]] sauber
- [[X]] trocken
- [[X]] tragfähig
- [[X]] frei von trennenden Substanzen
- [[X]] gleichmäßig saugfähig
- [[ ]] Haarrisse sind unerheblich
- [[ ]] leicht angeraute Unterfläche, damit es besser haftet
- [[ ]] leicht angefeuchtet, damit das Auftragen leichter geht

</div>
<div class="flex-child-2">

@Maler_Taetigkeiten.Koje_Vorbereitung(35)

</div>
</section>


### Haftfestigkeit alter Anstriche

><!--style="color: red; font-weight: bolder"-->Es sind insgesamt vier Antworten richtig!

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Mit welchen Methoden kann die Haftfestigkeit alter Anstriche geprüft werden?


<!-- data-randomize -->
- [[X]] Abriebprobe/Wischprobe mit der Hand oder einem Tuch
- [[ ]] Abkärchern
- [[X]] Kratzprobe mit dem Spachtel
- [[X]] Tragfähigkeitsprüfung mit Klebebandtest
- [[ ]] Besprühen der Wand mit Parfüm oder Duftstoffen
- [[X]] Abklopfen mit dem Finger
- [[ ]] Farbauftragstest

</div>
<div class="flex-child">

![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 250px; width: 100%" -->

</div>
</section>



### Saugfähigkeit eines Untergrundes

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Wie prüft man am besten die Saugfähigkeit eines Untergrunds?


<!-- data-randomize -->
- [(X)] Benetzungsprobe mit Wasser
- [( )] Farbauftragstest
- [( )] Kratzprobe mit Messer
- [( )] Klopfprobe

</div>
<div class="flex-child-3">

![Wandoberfläche mit geriffelter Struktur.](assets/images/putz.jpg "Geriffelte Wandstruktur mit rauem Putz. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/wand-fels-muster-struktur-schmutz-1979476/), Pixabay Content License, veröffentlicht am 15. Januar 2017.")<!-- style="max-width: 350px; width: 100%" -->

</div>
</section>

### Feuchtigkeitsmessung

><!--style="color: red; font-weight: bolder"-->Es sind insgesamt vier Antworten richtig!

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Wann ist eine Feuchtigkeitsprüfung sinnvoll?


<!-- data-randomize -->
- [[X]] bei sichtbarem oder vermuteten Schimmelbefall
- [[X]] bei sichtbaren oder vermuteten Wasserschäden
- [[X]] wenn dunkle Flecken an den Wänden sichtbar sind
- [[ ]] Die Prüfung der Feuchte ersetzt immer die Kontrolle von Rissen, Staub und Tragfähigkeit.
- [[ ]] immer - auch wenn die Umgebung trocken ist
- [[ ]] Eine Feuchtigkeitsprüfung ist zugleich eine Temperaturmessung und daher immer sinnvoll.
- [[X]] Eine Feuchtigkeitsprüfung geht jedem Farbanstrich voraus, um die Haftfestigkeit zu prüfen.

</div>
<div class="flex-child-1">

![Wand streichen](assets/images/malerrolle.jpg "_Quelle: Pixabay, Giordano_")<!-- style="max-width: 350px; width: 100%" -->

</div>
</section>



### Prüfgeräte für Untergrundprüfungen

><!--style="color: red; font-weight: bolder"-->Es sind insgesamt drei Antworten richtig!

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Prüfgeräte oder Hilfsmittel werden häufig bei Untergrundprüfungen im Malerhandwerk eingesetzt?


<!-- data-randomize -->
- [[ ]] Rückprallbolzen
- [[ ]] Haftmessgerät
- [[ ]] Lupe
- [[X]] Hydrometer
- [[X]] Gitterschnitt
- [[X]] Schichtdickenmessgerät (Lack)

</div>
<div class="flex-child-0">

<br>
<br>

![Farbeimer mit gelbem Deckel, Malerband und Malerwerkzeug in einem Raum während Renovierungsarbeiten.](assets/images/malerrollen_fensterbrett.jpg "Malerwerkzeug und Farbeimer bei Renovierungsarbeiten in einem Innenraum. Bild von [stux via Pixabay](https://pixabay.com/photos/renovate-painting-work-painting-1186334/), Pixabay Content License, veröffentlicht am 9. Februar 2016.")<!-- style="max-width: 400px; width: 100%" -->

</div>
</section>


## Geschafft 🎉

![Bunte Silhouetten mehrerer springender Menschen vor weißem Hintergrund als Symbol für Freude, Spaß und Lebensfreude.](assets/images/colorfull_jumping.jpg "Farbige Silhouetten springender Menschen als Ausdruck von Freude und Spaß. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/freude-springen-luftsprung-spa%C3%9F-3940425/), Pixabay Content License, veröffentlicht am 19. Januar 2019.")
